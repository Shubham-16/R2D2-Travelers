  <div class="modal fade" id="login" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">


        <div class="modal-header">
          <h4 class="modal-tile">Login</h4>
          <button class="close" data-dismiss="modal">&times;</button>
        </div>


        <div class="modal-body">
          <form class="p-5 bg-white" action="validate.php" method="post">
            <div class="row form-group">
              <div class="col-md-6 mb-3 mb-md-0">
                <label class="text-black" for="fname">Username</label>
                <input type="text" id="uname" name="uname" class="form-control" placeholder="Username">
              </div>
            </div>

            <div class="row form-group">
              <div class="col-md-6 mb-3 mb-md-0">
                <label class="text-black" for="date">Password</label> 
                <input type="text" id="pass" name="pass" class="form-control" placeholder="Password">
              </div>
            </div>
            <input type="submit" value="Login">
          </form>
        </div>


        <div class="modal-footer">
          <button class="btn btn-info" data-toggle="modal" data-target="#register" data-dismiss="modal">Register</button>
        </div>
      </div>
    </div>
  </div>
  <?php require('register.php') ?>