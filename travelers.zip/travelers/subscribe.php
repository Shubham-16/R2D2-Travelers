<?php
$email=$_POST['email'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'travel');
$q="INSERT INTO subscribe(Email) values('$email')";
$status=mysqli_query($con,$q);
mysqli_close($con);
?>
<?php
if ($status==1)
{
	
echo '<script language="javascript">';
echo 'alert("Thank You for subscribing")';
echo '</script>';
header("refresh:0,url=index.php" );
exit;

}


?>