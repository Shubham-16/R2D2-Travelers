<div class="modal fade" id="register" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">


        <div class="modal-header">
          <h4 class="modal-tile">Register</h4>
          <button class="close" data-dismiss="modal">&times;</button>
          
        </div>


        <div class="modal-body">
          <form class="p-5 bg-white" action="insert.php" method="post">
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">First Name</label>
                  <input type="text" id="fname" name="fname" class="form-control" placeholder="First Name" required autofocus>
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Last Name</label>
                  <input type="text" id="lname" name="lname" class="form-control" placeholder="Last Name" required autofocus>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="email">Username</label> 
                  <input type="text" id="user" name="user"  class="form-control" placeholder="example#123" required autofocus>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="email">Email</label> 
                  <input type="email" id="email" name="email" class="form-control" placeholder="Email" required autofocus>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="email">Password</label> 
                  <input type="text" id="pass" name="pass" class="form-control" placeholder="Password" required autofocus>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="email">confirm password</label> 
                  <input type="text" id="cpass" name="cpass" class="form-control" placeholder="Confirm Password" required autofocus>
                </div>
              </div>
              <input type="submit" value="submit">
          </form>
        </div>


        <div class="modal-footer">
          <button class="btn btn-primary" data-dismiss="modal">Cancel</button>
        </div>


      </div>
    </div>
  </div>
</div>

<!-- <script>
  $(document).ready(function(){
    $("insert_form").on('submit',function(event){
      $.ajax({
        url:"insert.php",
        method="post",
        data:$('#insert_form').serialize(),
        success:function(data)
        {
          $('#insert_form')[0].reset();
          $('#register').modal('hide');
        }
      })
    })
  })
</script> -->