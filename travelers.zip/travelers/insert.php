<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['user'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$cpass=$_POST['cpass'];
if ($pass!=$cpass)
{
	
echo '<script language="javascript">';
echo 'alert("Passwords not match")';
echo '</script>';
header( "refresh:2; url=index.php" );
exit;

}

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'travel');
$q="INSERT INTO register(fname,lname,uname,email,pass,cpass) values('$fname','$lname','$uname','$email','$pass','$cpass')";
$status=mysqli_query($con,$q);
mysqli_close($con);
?>
<?php
if ($status==1)
{
	
echo '<script language="javascript">';
echo 'alert("message submitted")';
echo '</script>';
header( "refresh:2; url=index.php" );
exit;

}


?>