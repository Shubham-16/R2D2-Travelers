<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'travel');
$q="INSERT INTO contact(fname,lname,email,subject,message) values('$fname','$lname','$email','$subject','$message')";
$status=mysqli_query($con,$q);
mysqli_close($con);
?>
<?php
if ($status==1)
{
	
echo '<script language="javascript">';
echo 'alert("Query submitted")';
echo '</script>';
header( "refresh:2; url=contact.php" );
exit;

}


?>