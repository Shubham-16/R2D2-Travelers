
<!DOCTYPE html>
<html lang="en">
 <?php
 session_start()
 ?>
  <head>
    <title>Travalers</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">

    <!-- <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> -->
    <header class="site-navbar py-1" role="banner" style="background-color: #f4eff1">

          <div class="container">
            <div class="row align-items-center">
              
              <div class="col-6 col-xl-2">
                <h1 class="mb-0"><a href="index.php" class="text-black h2 mb-0">Travelers</a></h1>
              </div>
              <div class="col-10 col-md-8 d-none d-xl-block">
                <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">

                  <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                    <li class="active">
                      <a href="index.php">Home</a>
                    </li>
                    <li class="has-children">
                      <a href="destination.php">Destinations</a>
                      <ul class="dropdown">
                        <li><a href="asia.php">Asia</a></li>
                        <li><a href="europe.php">Europe</a></li>
                        <li><a href="africa.php">Africa</a></li>
                        <li><a href="australia.php">Australia</a></li>
                      </ul>
                    </li>
                    
                    <li><a href="discount.php">Discount</a></li>
                    <li><a href="about.php">About</a></li>
                    <!-- <li><a href="blog.php">Blog</a></li> -->
                    
                    <li><a href="contact.php">Contact</a></li>
                    <!-- <li><a href="booking.html">Book Online</a></li> -->
                    <li class="has-children">
                    <?php 
                    if(isset($_SESSION['username']))
                    {
                      echo '<span class="text-dark">'.$_SESSION['username'].'</span>';?>
                      <ul class="dropdown">
                        <li><a href="logout.php">Logout</a></li>
                      </ul>
                      <?php
                    }
                    ?>
                  </li>
                  </ul>
                </nav>
              
              </div>
              <button class="btn btn-primary py-3 px-5 text-white" data-target="#login" data-toggle="modal">Login</button>
              <?php 
              require('Login.php') 
              ?>
            </div>
          </div>
          
        </header>
