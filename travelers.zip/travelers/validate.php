<?php
session_start();
$username=$_POST['uname'];
$password=$_POST['pass'];
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'travel');
$q="select * from register where uname='$username' && pass='$password'";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
if($num==1)
{
	$_SESSION['username']=$username;
	header( "refresh:2; url=index.php" );
	exit;	
}
else
{
	echo '<script language="javascript">';
	echo 'alert("Login credentials are Incorrect")';
	echo '</script>';
	header( "refresh:2; url=index.php" );
	exit;
}
?>