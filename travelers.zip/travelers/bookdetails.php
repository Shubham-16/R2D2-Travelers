<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$date=$_POST['date'];
$email=$_POST['email'];
$persons=$_POST['person'];
$dest=$_POST['destination'];
$note=$_POST['note'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'travel');
$q="INSERT INTO booking(firstname,lastname,traveldate,email,persons,destination,notes) values('$fname','$lname',$date,'$email',$persons,'$dest','$note')";
$status=mysqli_query($con,$q);
mysqli_close($con);
?>
<?php
if ($status==1)
{
	
echo '<script language="javascript">';
echo 'alert("Booking Confirmed.We will contact you Shortly.")';
echo '</script>';
header( "refresh:0; url=index.php" );
exit;

}


?>